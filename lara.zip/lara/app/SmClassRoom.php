<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmClassRoom extends Model
{
    //
}
