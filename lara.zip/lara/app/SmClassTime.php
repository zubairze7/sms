<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmClassTime extends Model
{
    //
}
