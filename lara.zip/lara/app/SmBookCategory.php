<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmBookCategory extends Model
{
    //
}
