<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmStudentExcelFormat extends Model
{
    public $timestamps = false;
}
