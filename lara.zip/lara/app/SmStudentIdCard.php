<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmStudentIdCard extends Model
{
    //
}
