<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmHoliday extends Model
{
    //
}
