<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmFeesCarryForward extends Model
{
    //
}
