<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmCurrency extends Model
{
    //
}
