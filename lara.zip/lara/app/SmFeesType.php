<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmFeesType extends Model
{
    //
}
