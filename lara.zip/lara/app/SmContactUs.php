<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmContactUs extends Model
{
    //
}
