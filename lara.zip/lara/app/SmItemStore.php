<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmItemStore extends Model
{
    //
}
