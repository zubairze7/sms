<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmSession extends Model
{
    //
}
