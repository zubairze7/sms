<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmStudentTakeOnlnExQuesOption extends Model
{
    //
}
