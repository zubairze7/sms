<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Storage;
use Response;

class DownloadController extends Controller
{
    function downloadFile(Request $request) { 

    }

}
