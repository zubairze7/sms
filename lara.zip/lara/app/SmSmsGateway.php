<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmSmsGateway extends Model
{
    //
}
